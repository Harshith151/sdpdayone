package sample;
import java.util.*;
public class sample 
{
	public static void main(String args[])
	{
		addition a = new addition();
		int c = a.m();
		System.out.println(c);
		
		
		oddeven b= new oddeven();
		b.x();
		
		
		MinMax1 d= new MinMax1();
		d.y();
		
		GFG e= new GFG();
		e.z();
		
		mul f= new mul();
		f.u();
		
		
		
	}
}
