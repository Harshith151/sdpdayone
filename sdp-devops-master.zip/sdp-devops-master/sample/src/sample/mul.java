package sample;
import java.util.*;
public class mul
{
	public void u()
	{
int x = 12;
int y = 13;
int z = x * y;
System.out.println("Multiplication: " + z);
}
}