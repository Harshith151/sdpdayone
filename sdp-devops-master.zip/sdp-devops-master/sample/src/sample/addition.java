package sample;
import java.util.*;
public class addition 
{

	public int m() {
		Scanner sc= new Scanner(System.in);
		int a= sc.nextInt();
		int b= sc.nextInt();
		int c= a+b;
		return(c);
	}
	
		
	
}
